from pathlib import Path,PurePosixPath
import gzip,tarfile,zipfile,shutil,stat,tempfile,struct,zlib
from common import *

def _find_7z():
    for cand in [BASE/'runtime/7zip/7z.exe', BASE/'runtime/7zip/7zz', BASE/'runtime/7zip/7z']:
        if cand.is_file(): return cand
    for name in ('7zz', '7z', '7za'):
        found = shutil.which(name)
        if found: return Path(found)
    return BASE/'runtime/7zip/7z.exe' if os.name=='nt' else BASE/'runtime/7zip/7zz'

SEVEN=_find_7z()
# Given when no password was typed, so 7-Zip reports a wrong password instead of waiting for someone to type one.
NO_PASSWORD='dropdial-no-password-given'

def vint(value):
    output=bytearray()
    while value>=128:output.append((value&127)|128);value>>=7
    output.append(value);return bytes(output)

def rar_header(stream,body):
    header=vint(len(body))+body;stream.write(struct.pack('<I',zlib.crc32(header)&0xffffffff)+header)

def stored_rar(folder,path):
    # RAR 5.0 store method, matching Tangerine's uncompressed RAR export.
    # Structure follows https://www.rarlab.com/technote.htm.
    with open(path,'wb') as output:
        output.write(b'Rar!\x1a\x07\x01\x00');rar_header(output,vint(1)+vint(0)+vint(0))
        for file in sorted(folder.rglob('*')):
            directory=file.is_dir();size=0 if directory else file.stat().st_size;crc=0
            if not directory:
                with open(file,'rb') as source:
                    for block in iter(lambda:source.read(1<<20),b''):crc=zlib.crc32(block,crc)
            name=file.relative_to(folder).as_posix().encode('utf8');flags=6|(1 if directory else 0)
            body=vint(2)+vint(2)+vint(size)+vint(flags)+vint(size)+vint(16 if directory else 32)+struct.pack('<I',int(file.stat().st_mtime)&0xffffffff)+struct.pack('<I',crc&0xffffffff)+vint(0)+vint(0)+vint(len(name))+name
            rar_header(output,body)
            if not directory:
                with open(file,'rb') as source:shutil.copyfileobj(source,output)
        rar_header(output,vint(5)+vint(0)+vint(0))

MAX_ENTRIES=20000
MAX_BYTES=10_000_000_000

def check_scale(count,size):
    if count>MAX_ENTRIES or size>MAX_BYTES: raise ValueError(T('The archive is too large to extract (too many files or too much data)'))

def safe_name(name):
    name=name.replace('\\','/'); path=PurePosixPath(name)
    if path.is_absolute() or '..' in path.parts or any(':' in part for part in path.parts): raise ValueError(T('The archive contains unsafe file paths'))
    return path

def extract_to(path,folder,params=None):
    path=Path(path); suffix=path.suffix.lower(); secret=(params or {}).get('password','')
    if suffix=='.zip' and not secret and not zip_needs_password(path):
        with zipfile.ZipFile(path) as archive:
            entries=archive.infolist(); check_scale(len(entries),sum(x.file_size for x in entries))
            for entry in entries:
                safe_name(entry.filename)
                if stat.S_ISLNK(entry.external_attr>>16): raise ValueError(T('Symbolic links in archives are not extracted'))
            archive.extractall(folder)
    elif tarfile.is_tarfile(path):
        with tarfile.open(path) as archive:
            entries=archive.getmembers(); check_scale(len(entries),sum(x.size for x in entries))
            for entry in entries:
                safe_name(entry.name)
                if not (entry.isfile() or entry.isdir()): raise ValueError(T('Links and device files in archives are not extracted'))
            archive.extractall(folder,filter='data')
    elif suffix in ('.gz','.gzip'):
        # gzip has no trustworthy size header, so enforce the limit while decompressing.
        written=0
        with gzip.open(path,'rb') as source,open(folder/path.stem,'wb') as target:
            for block in iter(lambda:source.read(1<<20),b''):
                written+=len(block); check_scale(1,written); target.write(block)
    elif suffix in ('.rar','.7z','.zip'):
        if not SEVEN.exists(): raise ValueError(T('Extracting RAR needs 7-Zip'))
        password=[f'-p{secret or NO_PASSWORD}']
        try: listing=process([SEVEN,'l','-slt','-ba','-sccUTF-8',*password,path]); count=size=0
        except RuntimeError as error: raise wrong_password(error) from None
        for line in listing.splitlines():
            if line.startswith('Path = '): safe_name(line[7:]); count+=1
            if line.startswith('Size = ') and line[7:].strip().isdigit(): size+=int(line[7:])
            if line.startswith(('Symbolic Link = ','Hard Link = ')) and line.split('=',1)[1].strip(): raise ValueError(T('Links in archives are not extracted'))
        check_scale(count,size)
        try: process([SEVEN,'x','-y','-sccUTF-8',f'-o{folder}',*password,path])
        except RuntimeError as error: raise wrong_password(error) from None
        for file in folder.rglob('*'):
            if file.is_symlink(): raise ValueError(T('The extracted files contain links'))
    else: raise ValueError(T('Unsupported archive format'))

def zip_needs_password(path):
    try:
        with zipfile.ZipFile(path) as archive: return any(entry.flag_bits&1 for entry in archive.infolist())
    except zipfile.BadZipFile: return False

def wrong_password(error):
    text=str(error)
    if 'password' in text.lower() or 'Wrong' in text or 'Cannot open encrypted' in text: return ValueError(T('The archive needs the correct password'))
    return error

def pack(folder,path,fmt):
    files=sorted(folder.rglob('*'))
    if fmt=='7z':
        if not SEVEN.exists(): raise ValueError(T('Making 7z or password-protected archives needs 7-Zip'))
        process([SEVEN,'a','-t7z','-mx=5','-sccUTF-8','-bd',path,'*'],cwd=folder)
        return
    if fmt=='zip':
        with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as archive:
            for file in files:
                archive.write(file,file.relative_to(folder).as_posix()+('/' if file.is_dir() else ''))
    elif fmt in ('tar','gz','gzip'):
        with tarfile.open(path,'w:gz' if fmt in ('gz','gzip') else 'w') as archive:
            for file in folder.iterdir(): archive.add(file,arcname=file.name)
    elif fmt=='rar':
        stored_rar(folder,path)
    else: raise ValueError(T('Unsupported archive output'))

def copy_selection(paths,folder):
    for path in paths:
        path=Path(path); target=folder/path.name
        if target.exists(): raise ValueError(T('Some selected files have the same name; please process them separately'))
        if path.is_dir(): shutil.copytree(path,target,symlinks=False)
        else: shutil.copy2(path,target)

def convert(paths,fmt,params):
    with tempfile.TemporaryDirectory(prefix='dropdial-archive-') as temp:
        folder=Path(temp)
        if not params.get('_pack') and len(paths)==1 and Path(paths[0]).suffix.lower() in ('.zip','.tar','.gz','.tgz','.rar','.7z'): extract_to(paths[0],folder)
        else: copy_selection(paths,folder)
        extension='.tar.gz' if fmt in ('gz','gzip') else '.'+fmt
        with output_file(paths[0],'packed' if params.get('_pack') else 'converted',extension) as state: pack(folder,state['temp'],fmt)
    return state['output']

def extract(path,params):
    with output_folder(path,'extracted',allow_empty=True) as state: extract_to(path,state['temp'],params)
    return state['output']

def pack_archive(paths,params):
    """Pack files and folders as ZIP or 7z with an optional password (AES-256) and an optional volume size."""
    fmt=params.get('format','zip'); secret=params.get('password',''); level=int(number(params,'level',5)); volume=number(params,'splitMB',0)
    if fmt in ('tar.gz', 'gz', 'gzip', 'tar'):
        return convert(paths, 'gz' if 'gz' in fmt else 'tar', {**params, '_pack': True})
    if fmt not in ('zip','7z') or not 1<=level<=9 or not 0<=volume<=100000: raise ValueError(T('The archive settings are not valid'))
    if not SEVEN.exists():
        if fmt == 'zip' and not secret and not volume:
            with tempfile.TemporaryDirectory(prefix='dropdial-archive-') as temp:
                folder=Path(temp)/'content'; folder.mkdir(); copy_selection(paths,folder)
                with output_file(paths[0],'packArchive','.zip') as state: pack(folder,state['temp'],'zip')
            return state['output']
        raise ValueError(T('Making 7z or password-protected archives needs 7-Zip'))
    with tempfile.TemporaryDirectory(prefix='dropdial-archive-') as temp:
        folder=Path(temp)/'content'; folder.mkdir(); copy_selection(paths,folder)
        options=['-sccUTF-8','-bd',f'-mx={level}']
        if secret: options+=[f'-p{secret}']+(['-mem=AES256'] if fmt=='zip' else ['-mhe=on'])
        if volume: options+=[f'-v{int(volume)}m']
        if volume:
            with output_folder(paths[0],'packArchive') as state: process([SEVEN,'a',f'-t{fmt}',*options,state['temp']/(output_stem(paths[0],'packed')+'.'+fmt),'*'],cwd=folder)
        else:
            with output_file(paths[0],'packArchive','.'+fmt) as state: process([SEVEN,'a',f'-t{fmt}',*options,state['temp'],'*'],cwd=folder)
    return state['output']
